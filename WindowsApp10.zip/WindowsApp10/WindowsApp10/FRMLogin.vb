﻿
Public Class FRMLogin
    Public Property CashierName As String
    Dim conn As New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Acer\Documents\VBNetCaseStudy.mdb; persist security info = false") 'just for connection

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("Username and password are blank", "Authentication Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Try
                conn.Open()

                Dim sql As String = "SELECT * FROM users WHERE user_name='" & txtUsername.Text & "' AND pass_word='" & txtPassword.Text & "'"
                Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql) 'nag initialize lang ng variable para sa command bida bida kasi 

                sqlCom.Connection = conn
                Dim sqlRead As System.Data.OleDb.OleDbDataReader 'initialize reader para ma basa yung laman ng data source

                sqlRead = sqlCom.ExecuteReader() 'babasahin na data / pede na rin sabihin na nag r-retrieve 


                If sqlRead.Read() Then
                    If sqlRead.Item("user_type") = "Cashier" Then
                        Dim cashierForm As New FRMCashier()
                        CashierName = sqlRead.Item("Name").ToString()
                        cashierForm.Show()
                        Me.Hide()
                    ElseIf sqlRead.Item("user_type") = "Admin" Then
                        FRMAdmin.Show()
                        Me.Hide()
                    Else
                        MessageBox.Show("Invalid user type.", "Authentication Failure", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    End If
                Else
                    MessageBox.Show("Username and Password do not match.", "Authentication Failure", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    txtUsername.Text = ""
                    txtPassword.Text = ""
                    txtUsername.Focus() 'ngayon ko lang nalaman na may ganto lupet hahha, babalik pag type dun sa textbox na naka focus
                End If

                sqlRead.Close() ' syempre pag binuksan need close yung reader 
                conn.Close()

            Catch ex As Exception
                MessageBox.Show("Failed to connect to Database: " & ex.Message, "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                If conn.State = ConnectionState.Open Then
                    conn.Close() 'Close connection para di mag error 
                End If
            End Try
        End If
    End Sub

    Private Sub ckbHide_CheckedChanged(sender As Object, e As EventArgs) Handles ckbHide.CheckedChanged
        If ckbHide.Checked Then
            txtPassword.PasswordChar = "*"c
        Else
            txtPassword.PasswordChar = ControlChars.NullChar
        End If
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPassword.Text = ""
        txtUsername.Text = ""
        txtUsername.Focus()
        ckbHide.Checked = True
    End Sub
End Class