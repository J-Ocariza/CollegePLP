﻿Imports System.Data.OleDb
Imports System.Drawing.Printing
Public Class FRMCashier
    Dim WithEvents PD As New PrintDocument
    Dim PPD As New PrintPreviewDialog
    Dim conn As New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Acer\Documents\VBNetCaseStudy.mdb; persist security info = false")

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textnull()
        LoadCmbProducts()
        LoadCmbPayment()
        lblDate.Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy - h:mm tt")
        buttonfalse()
        btnNewOrder.Enabled = True
        textfalse()
        txtTotalChange.Enabled = False
    End Sub
    Private Sub LoadCmbProducts()
        Try
            conn.Open()
            Dim sql As String = "select Product_Name FROM product_details"
            Dim sqlcom As New OleDbCommand(sql, conn)
            Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

            cmbProducts.Items.Clear()

            While sqlread.Read()
                cmbProducts.Items.Add(sqlread("Product_Name").ToString())
            End While

            sqlread.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally

            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub

    Private Sub LoadCmbPayment()
        Try
            conn.Open()
            Dim sql As String = "SELECT pay_method, available FROM payment_methods"
            Dim sqlcom As New OleDbCommand(sql, conn)
            Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

            cmbPaymentMethod.Items.Clear()

            While sqlread.Read()
                Dim payMethod As String = sqlread("pay_method").ToString()
                Dim available As String = sqlread("available").ToString()

                If available = "Yes" Then
                    cmbPaymentMethod.Items.Add(payMethod & " - Available")
                ElseIf available = "No" Then
                    cmbPaymentMethod.Items.Add(payMethod & " - Not Available")
                    'try mo nga gawin na gray kulay pag hindi available tas if pwede gawin mo na rin na hindi clickable.
                End If
            End While

            sqlread.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub

    Sub buttonTrue()
        btnAddItem.Enabled = True
        btnCancel.Enabled = True
        btnCheckout.Enabled = True
        btnRemoveItem.Enabled = True
        btnPrintReceipt.Enabled = True
        btnUpdate.Enabled = True
    End Sub

    Sub buttonfalse()
        btnAddItem.Enabled = False
        btnCancel.Enabled = False
        btnCheckout.Enabled = False
        btnRemoveItem.Enabled = False
        btnPrintReceipt.Enabled = False
        btnUpdate.Enabled = False
    End Sub

    Sub textfalse()
        txtCashTendered.Enabled = False
        txtQuantity.Enabled = False
        txtCVV.Enabled = False
        cmbPaymentMethod.Enabled = False
    End Sub
    Sub texttrue()
        txtCashTendered.Enabled = True
        txtQuantity.Enabled = True
        cmbPaymentMethod.Enabled = True
        txtCVV.Enabled = True
    End Sub

    Sub textnull()
        txtCashTendered.Text = ""
        txtQuantity.Text = ""
        txtCVV.Text = ""
        cmbPaymentMethod.Text = ""
        cmbProducts.Text = ""
        txtTotalChange.Text = ""
    End Sub

    Private Sub btnNewOrder_Click(sender As Object, e As EventArgs) Handles btnNewOrder.Click
        buttonTrue()
        cmbPaymentMethod.Enabled = True
        txtQuantity.Enabled = True
        textnull()

        btnCancel.Enabled = False
        btnUpdate.Enabled = False
        btnPrintReceipt.Enabled = False

        DataGridView1.Columns.Clear()
        DataGridView1.Rows.Clear()
        lblTotalOrders.Text = "0.00"

        Try
            ' Open the connection
            conn.Open()

            Dim sql As String = "SELECT MAX(Order_id) AS NewOrderID FROM Orders"
            Dim sqlcom As New OleDbCommand(sql, conn)

            ' kunin yung last number
            Dim Ordernum As Object = sqlcom.ExecuteScalar()

            ' display number + 1
            If Not IsDBNull(Ordernum) Then
                lblOrderNo.Text = Ordernum.ToString() + 1
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Close the connection
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub

    Private Sub btnAddItem_Click(sender As Object, e As EventArgs) Handles btnAddItem.Click
        Try
            conn.Open()
            Dim product As String = cmbProducts.SelectedItem.ToString()
            Dim quantity As String = txtQuantity.Text


            Dim sqlID As String = "SELECT product_id, product_name, price FROM product_details WHERE product_name = '" & product & "'"
            Dim sqlcom As New OleDbCommand(sqlID, conn)
            Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

            If cmbProducts.SelectedItem IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(txtQuantity.Text) AndAlso IsNumeric(txtQuantity.Text) Then
                If sqlread.Read() Then
                    Dim product_id As String = sqlread("product_id").ToString()
                    Dim product_price As Decimal = Convert.ToDecimal(sqlread("price"))
                    Dim subtotal As Decimal = quantity * product_price

                    DataGridView1.ColumnCount = 5

                    DataGridView1.Columns(0).Name = "Product_ID"
                    DataGridView1.Columns(1).Name = "Product_Name"
                    DataGridView1.Columns(2).Name = "Quantity"
                    DataGridView1.Columns(3).Name = "Product_Price"
                    DataGridView1.Columns(4).Name = "Subtotal"

                    Dim rowIndex As Integer = DataGridView1.Rows.Add()
                    DataGridView1.Rows(rowIndex).Cells(0).Value = product_id
                    DataGridView1.Rows(rowIndex).Cells(1).Value = product
                    DataGridView1.Rows(rowIndex).Cells(2).Value = quantity
                    DataGridView1.Rows(rowIndex).Cells(3).Value = product_price
                    DataGridView1.Rows(rowIndex).Cells(4).Value = subtotal

                End If
            Else
                MessageBox.Show("Please select a product and enter a valid quantity.")
            End If

            sqlread.Close()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try

        cmbProducts.Text = ""
        txtQuantity.Text = ""
        CalculateTotalOrders()

    End Sub
    Sub CalculateTotalOrders()
        Dim total As Decimal = 0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                Dim subtotal As Decimal = Convert.ToDecimal(row.Cells("Subtotal").Value)
                total += subtotal
            End If
        Next

        lblTotalOrders.Text = total.ToString()
    End Sub

    Sub calculateChange()
        Dim change As Decimal
        Dim totalOrder As Decimal = lblTotalOrders.Text
        Dim cash As Decimal = txtCashTendered.Text
        If cash < totalOrder Then
            MessageBox.Show("Amount entered is not enough!", "Payment Not Enough!", MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf cash >= totalOrder Then
            change = cash - totalOrder
            txtTotalChange.Text = change.ToString
            textfalse()
            buttonfalse()
            btnCancel.Enabled = True
            btnPrintReceipt.Enabled = True
        End If
    End Sub

    Private Sub btnCheckout_Click(sender As Object, e As EventArgs) Handles btnCheckout.Click
        If Not String.IsNullOrEmpty(cmbPaymentMethod.Text) Then
            If cmbPaymentMethod.Text = "Cash - Available" Then
                cash()
            ElseIf cmbPaymentMethod.Text = "Card - Available" Then
                MessageBox.Show("CARD - PLEASE ENTER CVV", "CARD", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else
                MessageBox.Show("Please choose payment method", "Choose payment method!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Else
            MessageBox.Show("Please choose payment method", "Choose payment method!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        buttonfalse()
        textfalse()
        btnUpdate.Enabled = True
        btnNewOrder.Enabled = True
    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        buttonfalse()
        btnRemoveItem.Enabled = True
        btnAddItem.Enabled = True
        btnCheckout.Enabled = True
        texttrue()
        txtCVV.Enabled = False
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        conn.Open()

        Dim sql As String = "SELECT product_id, product_name, price FROM product_details WHERE product_name LIKE '%" & cmbProducts.Text & "%'"
        Dim sqlcom As New OleDbCommand(sql, conn)
        Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

        If sqlread.Read() Then
            MessageBox.Show("Product Information:" & vbCrLf &
                            "Product ID: " & sqlread("product_id").ToString() & vbNewLine &
                            "Product Name: " & sqlread("product_name").ToString() & vbNewLine &
                            "Product Price: " & sqlread("price").ToString(),
                            "Product Found",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
        Else
            MessageBox.Show("Product not found", "No Product Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

        sqlread.Close()
        conn.Close()
        cmbProducts.Text = ""
    End Sub
    Sub cash()
        Try
            If Not String.IsNullOrEmpty(txtCashTendered.Text) AndAlso IsNumeric(txtCashTendered.Text) Then
                calculateChange()
            Else
                MessageBox.Show("Please enter a valid amount", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        FRMLogin.ShowDialog()
    End Sub

    Private Sub btnRemoveItem_Click(sender As Object, e As EventArgs) Handles btnRemoveItem.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Get the selected row
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)

            ' Retrieve the subtotal value from the selected row
            Dim subtotalValue As Double = CDbl(selectedRow.Cells("subtotal").Value)

            ' Ask for confirmation or perform deletion directly
            If MessageBox.Show("Are you sure you want to delete the item?", "Confirmation", MessageBoxButtons.YesNo) = DialogResult.Yes Then
                ' Remove the selected row
                DataGridView1.Rows.Remove(selectedRow)

                ' Update the total orders label by subtracting the subtotal value
                lblTotalOrders.Text = (CDbl(lblTotalOrders.Text) - subtotalValue).ToString()
            End If
        Else
            MessageBox.Show("Please select a row to delete.")
        End If
    End Sub

    Private Sub PD_BeginPrint(sender As Object, e As Printing.PrintEventArgs) Handles PD.BeginPrint
        Dim pagesetup As New PageSettings
        pagesetup.PaperSize = New PaperSize("Custom", 350, 600)
        PD.DefaultPageSettings = pagesetup
    End Sub
    Private Sub PD_PrintPage(sender As Object, e As PrintPageEventArgs) Handles PD.PrintPage
        Dim f8 As New Font("Calibri", 8, FontStyle.Regular)
        Dim f10 As New Font("Calibri", 10, FontStyle.Regular)
        Dim f10b As New Font("Calibri", 10, FontStyle.Bold)
        Dim f14 As New Font("Calibri", 14, FontStyle.Bold)

        Dim leftmargin As Integer = PD.DefaultPageSettings.Margins.Left
        Dim centermargin As Integer = PD.DefaultPageSettings.PaperSize.Width / 2
        Dim rightmargin As Integer = PD.DefaultPageSettings.PaperSize.Width

        'font alignment
        Dim right As New StringFormat
        Dim center As New StringFormat

        right.Alignment = StringAlignment.Far
        center.Alignment = StringAlignment.Center

        Dim line As String
        line = "=========================================================================="

        e.Graphics.DrawString("AAB Store", f14, Brushes.Black, centermargin, 5, center)
        e.Graphics.DrawString("PLP Kapasigan Pasig City", f10, Brushes.Black, centermargin, 25, center)
        e.Graphics.DrawString("Tel +639994789321", f8, Brushes.Black, centermargin, 40, center)

        e.Graphics.DrawString("Invoice ID", f10, Brushes.Black, 5, 60) ' ginaya ko lang to sa tutorial pero pwder naman wala 
        e.Graphics.DrawString(":", f10, Brushes.Black, 61, 60)
        e.Graphics.DrawString("KFGS1654", f10, Brushes.Black, 70, 60)

        e.Graphics.DrawString("Cashier", f10, Brushes.Black, 5, 75)
        e.Graphics.DrawString(":", f10, Brushes.Black, 61, 75)
        e.Graphics.DrawString(FRMLogin.CashierName, f10, Brushes.Black, 70, 75)

        e.Graphics.DrawString(lblDate.Text, f10, Brushes.Black, 5, 90)
        e.Graphics.DrawString("Order ID : " + lblOrderNo.Text, f10b, Brushes.Black, rightmargin, 90, right)

        e.Graphics.DrawString(line, f8, Brushes.Black, 0, 100)


        Dim height As Integer 'dgv position
        Dim i As Long
        DataGridView1.AllowUserToAddRows = False

        For row As Integer = 0 To DataGridView1.RowCount - 1
            height += 15
            e.Graphics.DrawString(DataGridView1.Rows(row).Cells(3).Value.ToString, f10, Brushes.Black, 0, 100 + height)
            e.Graphics.DrawString("x" + DataGridView1.Rows(row).Cells(2).Value.ToString, f10, Brushes.Black, 35, 100 + height)
            e.Graphics.DrawString(DataGridView1.Rows(row).Cells(1).Value.ToString, f10, Brushes.Black, 50, 100 + height)

            i = DataGridView1.Rows(row).Cells(4).Value = Format(i, "##,##0")
            e.Graphics.DrawString(DataGridView1.Rows(row).Cells(4).Value.ToString, f10, Brushes.Black, rightmargin, 100 + height, right)
        Next
        Dim height2 As Integer
        height2 = 110 + height
        e.Graphics.DrawString(line, f8, Brushes.Black, 0, height2)
        e.Graphics.DrawString("Total: " + lblTotalOrders.Text, f10b, Brushes.Black, rightmargin, 15 + height2, right)
        e.Graphics.DrawString("Qty", f10b, Brushes.Black, 35, 15 + height2)

        e.Graphics.DrawString("Cash Tendered: " + txtCashTendered.Text, f10b, Brushes.Black, rightmargin, 30 + height2, right)
        e.Graphics.DrawString("Change: " + txtTotalChange.Text, f10b, Brushes.Black, rightmargin, 45 + height2, right)

        e.Graphics.DrawString("--Thank you for shopping--", f10b, Brushes.Black, centermargin, 100 + height2, center)
        e.Graphics.DrawString("--AAB Store--", f10b, Brushes.Black, centermargin, 110 + height2, center)
    End Sub
    Private Sub btnPrintReceipt_Click(sender As Object, e As EventArgs) Handles btnPrintReceipt.Click
        insertOrders()
        insertProductDetails()

        PPD.Document = PD
        PPD.ShowDialog()
        buttonfalse()
        textfalse()
        textnull()
        btnNewOrder.Enabled = True
        DataGridView1.Columns.Clear()
        DataGridView1.Rows.Clear()
        lblOrderNo.Text = "-"
        lblTotalOrders.Text = "0.00"
    End Sub

    Sub insertProductDetails()
        Try
            conn.Open()

            For Each row As DataGridViewRow In DataGridView1.Rows
                If Not row.IsNewRow Then
                    Dim productID As String = row.Cells("Product_ID").Value.ToString()
                    Dim quantity As Integer = Convert.ToInt32(row.Cells("Quantity").Value)

                    ' Define variables for payment type and CVV
                    Dim paymentType As String = If(cmbPaymentMethod.Text.StartsWith("Cash"), "Cash", "Card")
                    Dim cvv As Integer = If(paymentType = "Card", Convert.ToInt32(txtCVV.Text), 0)

                    ' Build the SQL query to insert into order_details including payment type and CVV
                    Dim orderDetailsSql As String = "insert into order_details (Order_ID, Product_ID, Quantity, Payment_Type, Card_CVV) VALUES ('" & lblOrderNo.Text & "', '" & productID & "', " & quantity & ", '" & paymentType & "', " & cvv & ")"
                    Dim orderDetailsCmd As New OleDbCommand(orderDetailsSql, conn)

                    ' Execute the SQL command to insert order details
                    orderDetailsCmd.ExecuteNonQuery()
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Error inserting order_details: " & ex.Message)
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub
    Sub insertOrders()
        Try
            conn.Open()
            Dim orderdate As String = DateTime.Now.ToString("yyyy-MM-dd")
            Dim sql As String = "INSERT INTO orders VALUES ('" & lblOrderNo.Text & "', '" & lblTotalOrders.Text & "', '" & orderdate & "')"
            Dim sqlcom As New OleDbCommand(sql, conn)
            sqlcom.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("Error inserting orders: " & ex.Message)
        Finally
            If conn.State = ConnectionState.Open Then
                conn.Close()
            End If
        End Try
    End Sub

    Private Sub cmbPaymentMethod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbPaymentMethod.SelectedIndexChanged
        Dim selectedPaymentMethod As String = cmbPaymentMethod.SelectedItem.ToString()

        If selectedPaymentMethod.StartsWith("Cash") Then
            txtCashTendered.Enabled = True
            txtCVV.Enabled = False
            txtTotalChange.Text = ""
            txtCVV.Text = ""
        ElseIf selectedPaymentMethod.StartsWith("Card") Then
            txtCashTendered.Enabled = False
            txtCVV.Enabled = True
            txtCashTendered.Text = ""
            txtTotalChange.Text = ""
        Else
            txtCashTendered.Enabled = False
            txtCVV.Enabled = False
        End If

        If selectedPaymentMethod.EndsWith("Not Available") Then
            MessageBox.Show("CHOOSE ANOTHER PAYMENT METHOD", "Payment Method Not Available", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtCashTendered.Enabled = False
            txtCVV.Enabled = False
        End If
    End Sub
End Class