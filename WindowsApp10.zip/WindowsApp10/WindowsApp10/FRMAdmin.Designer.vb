﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRMAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FRMAdmin))
        Me.txtadd4 = New System.Windows.Forms.TextBox()
        Me.txtadd3 = New System.Windows.Forms.TextBox()
        Me.lbladd4 = New System.Windows.Forms.Label()
        Me.lbladd3 = New System.Windows.Forms.Label()
        Me.txtadd2 = New System.Windows.Forms.TextBox()
        Me.txtadd1 = New System.Windows.Forms.TextBox()
        Me.lbladd2 = New System.Windows.Forms.Label()
        Me.lbladd1 = New System.Windows.Forms.Label()
        Me.cmbADD = New System.Windows.Forms.ComboBox()
        Me.cmbID = New System.Windows.Forms.ComboBox()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.txtadvsearch = New System.Windows.Forms.TextBox()
        Me.btnadvsearch = New System.Windows.Forms.Button()
        Me.cmboperator = New System.Windows.Forms.ComboBox()
        Me.btnconfirm = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbtables = New System.Windows.Forms.ComboBox()
        Me.dtprep = New System.Windows.Forms.DateTimePicker()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.lblrep = New System.Windows.Forms.Label()
        Me.txtinputbox = New System.Windows.Forms.TextBox()
        Me.lblfield = New System.Windows.Forms.Label()
        Me.cmbfield = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblid = New System.Windows.Forms.Label()
        Me.btnsearch = New System.Windows.Forms.Button()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.btnedit = New System.Windows.Forms.Button()
        Me.DATAGRID = New System.Windows.Forms.DataGridView()
        Me.btnExitadmin = New System.Windows.Forms.Button()
        CType(Me.DATAGRID, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtadd4
        '
        Me.txtadd4.Enabled = False
        Me.txtadd4.Location = New System.Drawing.Point(313, 736)
        Me.txtadd4.Name = "txtadd4"
        Me.txtadd4.Size = New System.Drawing.Size(211, 22)
        Me.txtadd4.TabIndex = 96
        Me.txtadd4.Visible = False
        '
        'txtadd3
        '
        Me.txtadd3.Enabled = False
        Me.txtadd3.Location = New System.Drawing.Point(313, 698)
        Me.txtadd3.Name = "txtadd3"
        Me.txtadd3.Size = New System.Drawing.Size(211, 22)
        Me.txtadd3.TabIndex = 95
        Me.txtadd3.Visible = False
        '
        'lbladd4
        '
        Me.lbladd4.AutoSize = True
        Me.lbladd4.BackColor = System.Drawing.Color.Transparent
        Me.lbladd4.Enabled = False
        Me.lbladd4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd4.Location = New System.Drawing.Point(183, 738)
        Me.lbladd4.Name = "lbladd4"
        Me.lbladd4.Size = New System.Drawing.Size(69, 20)
        Me.lbladd4.TabIndex = 94
        Me.lbladd4.Text = "lbladd4"
        Me.lbladd4.Visible = False
        '
        'lbladd3
        '
        Me.lbladd3.AutoSize = True
        Me.lbladd3.BackColor = System.Drawing.Color.Transparent
        Me.lbladd3.Enabled = False
        Me.lbladd3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd3.Location = New System.Drawing.Point(183, 698)
        Me.lbladd3.Name = "lbladd3"
        Me.lbladd3.Size = New System.Drawing.Size(69, 20)
        Me.lbladd3.TabIndex = 93
        Me.lbladd3.Text = "lbladd3"
        Me.lbladd3.Visible = False
        '
        'txtadd2
        '
        Me.txtadd2.Enabled = False
        Me.txtadd2.Location = New System.Drawing.Point(313, 654)
        Me.txtadd2.Name = "txtadd2"
        Me.txtadd2.Size = New System.Drawing.Size(211, 22)
        Me.txtadd2.TabIndex = 92
        Me.txtadd2.Visible = False
        '
        'txtadd1
        '
        Me.txtadd1.Enabled = False
        Me.txtadd1.Location = New System.Drawing.Point(313, 616)
        Me.txtadd1.Name = "txtadd1"
        Me.txtadd1.Size = New System.Drawing.Size(211, 22)
        Me.txtadd1.TabIndex = 91
        Me.txtadd1.Visible = False
        '
        'lbladd2
        '
        Me.lbladd2.AutoSize = True
        Me.lbladd2.BackColor = System.Drawing.Color.Transparent
        Me.lbladd2.Enabled = False
        Me.lbladd2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd2.Location = New System.Drawing.Point(183, 656)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(69, 20)
        Me.lbladd2.TabIndex = 90
        Me.lbladd2.Text = "lbladd2"
        Me.lbladd2.Visible = False
        '
        'lbladd1
        '
        Me.lbladd1.AutoSize = True
        Me.lbladd1.BackColor = System.Drawing.Color.Transparent
        Me.lbladd1.Enabled = False
        Me.lbladd1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladd1.Location = New System.Drawing.Point(183, 616)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(69, 20)
        Me.lbladd1.TabIndex = 89
        Me.lbladd1.Text = "lbladd1"
        Me.lbladd1.Visible = False
        '
        'cmbADD
        '
        Me.cmbADD.Enabled = False
        Me.cmbADD.FormattingEnabled = True
        Me.cmbADD.Items.AddRange(New Object() {"Payment_Method", "Product_Details", "Users"})
        Me.cmbADD.Location = New System.Drawing.Point(360, 563)
        Me.cmbADD.Name = "cmbADD"
        Me.cmbADD.Size = New System.Drawing.Size(121, 24)
        Me.cmbADD.TabIndex = 88
        Me.cmbADD.Visible = False
        '
        'cmbID
        '
        Me.cmbID.Enabled = False
        Me.cmbID.FormattingEnabled = True
        Me.cmbID.Location = New System.Drawing.Point(922, 499)
        Me.cmbID.Name = "cmbID"
        Me.cmbID.Size = New System.Drawing.Size(121, 24)
        Me.cmbID.TabIndex = 87
        Me.cmbID.Visible = False
        '
        'btnadd
        '
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(186, 542)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(153, 59)
        Me.btnadd.TabIndex = 86
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'txtadvsearch
        '
        Me.txtadvsearch.Enabled = False
        Me.txtadvsearch.Location = New System.Drawing.Point(724, 531)
        Me.txtadvsearch.Name = "txtadvsearch"
        Me.txtadvsearch.Size = New System.Drawing.Size(620, 22)
        Me.txtadvsearch.TabIndex = 85
        Me.txtadvsearch.Visible = False
        '
        'btnadvsearch
        '
        Me.btnadvsearch.Enabled = False
        Me.btnadvsearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadvsearch.Location = New System.Drawing.Point(504, 543)
        Me.btnadvsearch.Name = "btnadvsearch"
        Me.btnadvsearch.Size = New System.Drawing.Size(153, 60)
        Me.btnadvsearch.TabIndex = 84
        Me.btnadvsearch.Text = "Advance Search"
        Me.btnadvsearch.UseVisualStyleBackColor = True
        Me.btnadvsearch.Visible = False
        '
        'cmboperator
        '
        Me.cmboperator.Enabled = False
        Me.cmboperator.FormattingEnabled = True
        Me.cmboperator.Location = New System.Drawing.Point(828, 579)
        Me.cmboperator.Name = "cmboperator"
        Me.cmboperator.Size = New System.Drawing.Size(40, 24)
        Me.cmboperator.TabIndex = 83
        Me.cmboperator.Visible = False
        '
        'btnconfirm
        '
        Me.btnconfirm.Enabled = False
        Me.btnconfirm.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconfirm.Location = New System.Drawing.Point(724, 618)
        Me.btnconfirm.Name = "btnconfirm"
        Me.btnconfirm.Size = New System.Drawing.Size(135, 30)
        Me.btnconfirm.TabIndex = 82
        Me.btnconfirm.Text = "Confirm"
        Me.btnconfirm.UseVisualStyleBackColor = True
        Me.btnconfirm.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(227, 92)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 24)
        Me.Label1.TabIndex = 81
        Me.Label1.Text = "Table"
        '
        'cmbtables
        '
        Me.cmbtables.FormattingEnabled = True
        Me.cmbtables.Items.AddRange(New Object() {"Order_Details", "Orders", "Payment_Methods", "Product_Details", "Users"})
        Me.cmbtables.Location = New System.Drawing.Point(197, 119)
        Me.cmbtables.Name = "cmbtables"
        Me.cmbtables.Size = New System.Drawing.Size(121, 24)
        Me.cmbtables.TabIndex = 80
        '
        'dtprep
        '
        Me.dtprep.CustomFormat = "M/d/yyyy"
        Me.dtprep.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtprep.Location = New System.Drawing.Point(874, 581)
        Me.dtprep.Name = "dtprep"
        Me.dtprep.Size = New System.Drawing.Size(220, 22)
        Me.dtprep.TabIndex = 79
        Me.dtprep.TabStop = False
        Me.dtprep.Value = New Date(2023, 12, 13, 15, 42, 49, 0)
        Me.dtprep.Visible = False
        '
        'btncancel
        '
        Me.btncancel.Enabled = False
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(922, 618)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(135, 30)
        Me.btncancel.TabIndex = 78
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        Me.btncancel.Visible = False
        '
        'lblrep
        '
        Me.lblrep.AutoSize = True
        Me.lblrep.BackColor = System.Drawing.Color.Transparent
        Me.lblrep.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrep.Location = New System.Drawing.Point(730, 581)
        Me.lblrep.Name = "lblrep"
        Me.lblrep.Size = New System.Drawing.Size(118, 20)
        Me.lblrep.TabIndex = 77
        Me.lblrep.Text = "Replacement"
        Me.lblrep.Visible = False
        '
        'txtinputbox
        '
        Me.txtinputbox.Enabled = False
        Me.txtinputbox.Location = New System.Drawing.Point(874, 581)
        Me.txtinputbox.Name = "txtinputbox"
        Me.txtinputbox.Size = New System.Drawing.Size(220, 22)
        Me.txtinputbox.TabIndex = 76
        Me.txtinputbox.Visible = False
        '
        'lblfield
        '
        Me.lblfield.AutoSize = True
        Me.lblfield.BackColor = System.Drawing.Color.Transparent
        Me.lblfield.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfield.Location = New System.Drawing.Point(759, 479)
        Me.lblfield.Name = "lblfield"
        Me.lblfield.Size = New System.Drawing.Size(50, 20)
        Me.lblfield.TabIndex = 75
        Me.lblfield.Text = "Field"
        Me.lblfield.Visible = False
        '
        'cmbfield
        '
        Me.cmbfield.Enabled = False
        Me.cmbfield.FormattingEnabled = True
        Me.cmbfield.Location = New System.Drawing.Point(724, 499)
        Me.cmbfield.Name = "cmbfield"
        Me.cmbfield.Size = New System.Drawing.Size(121, 24)
        Me.cmbfield.TabIndex = 74
        Me.cmbfield.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Enabled = False
        Me.Label2.Location = New System.Drawing.Point(730, 685)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 17)
        Me.Label2.TabIndex = 73
        Me.Label2.Visible = False
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.BackColor = System.Drawing.Color.Transparent
        Me.lblid.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblid.Location = New System.Drawing.Point(937, 479)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(92, 20)
        Me.lblid.TabIndex = 72
        Me.lblid.Text = "Unique ID"
        Me.lblid.Visible = False
        '
        'btnsearch
        '
        Me.btnsearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsearch.Location = New System.Drawing.Point(504, 478)
        Me.btnsearch.Name = "btnsearch"
        Me.btnsearch.Size = New System.Drawing.Size(153, 59)
        Me.btnsearch.TabIndex = 71
        Me.btnsearch.Text = "Search"
        Me.btnsearch.UseVisualStyleBackColor = True
        '
        'btndelete
        '
        Me.btndelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(345, 478)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(153, 59)
        Me.btndelete.TabIndex = 70
        Me.btndelete.Text = "Delete"
        Me.btndelete.UseVisualStyleBackColor = True
        '
        'btnedit
        '
        Me.btnedit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(186, 478)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(153, 59)
        Me.btnedit.TabIndex = 69
        Me.btnedit.Text = "Edit"
        Me.btnedit.UseVisualStyleBackColor = True
        '
        'DATAGRID
        '
        Me.DATAGRID.AllowUserToAddRows = False
        Me.DATAGRID.AllowUserToDeleteRows = False
        Me.DATAGRID.AllowUserToResizeRows = False
        Me.DATAGRID.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.DATAGRID.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DATAGRID.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DATAGRID.ColumnHeadersHeight = 29
        Me.DATAGRID.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DATAGRID.GridColor = System.Drawing.SystemColors.AppWorkspace
        Me.DATAGRID.Location = New System.Drawing.Point(186, 149)
        Me.DATAGRID.Name = "DATAGRID"
        Me.DATAGRID.RowHeadersWidth = 51
        Me.DATAGRID.RowTemplate.Height = 24
        Me.DATAGRID.Size = New System.Drawing.Size(1211, 323)
        Me.DATAGRID.TabIndex = 68
        '
        'btnExitadmin
        '
        Me.btnExitadmin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExitadmin.Location = New System.Drawing.Point(1292, 83)
        Me.btnExitadmin.Name = "btnExitadmin"
        Me.btnExitadmin.Size = New System.Drawing.Size(113, 46)
        Me.btnExitadmin.TabIndex = 67
        Me.btnExitadmin.Text = "Exit"
        Me.btnExitadmin.UseVisualStyleBackColor = True
        '
        'FRMAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1589, 840)
        Me.Controls.Add(Me.txtadd4)
        Me.Controls.Add(Me.txtadd3)
        Me.Controls.Add(Me.lbladd4)
        Me.Controls.Add(Me.lbladd3)
        Me.Controls.Add(Me.txtadd2)
        Me.Controls.Add(Me.txtadd1)
        Me.Controls.Add(Me.lbladd2)
        Me.Controls.Add(Me.lbladd1)
        Me.Controls.Add(Me.cmbADD)
        Me.Controls.Add(Me.cmbID)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.txtadvsearch)
        Me.Controls.Add(Me.btnadvsearch)
        Me.Controls.Add(Me.cmboperator)
        Me.Controls.Add(Me.btnconfirm)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbtables)
        Me.Controls.Add(Me.dtprep)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.lblrep)
        Me.Controls.Add(Me.txtinputbox)
        Me.Controls.Add(Me.lblfield)
        Me.Controls.Add(Me.cmbfield)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblid)
        Me.Controls.Add(Me.btnsearch)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.btnedit)
        Me.Controls.Add(Me.DATAGRID)
        Me.Controls.Add(Me.btnExitadmin)
        Me.DoubleBuffered = True
        Me.Name = "FRMAdmin"
        Me.Text = "ADMIN"
        CType(Me.DATAGRID, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtadd4 As TextBox
    Friend WithEvents txtadd3 As TextBox
    Friend WithEvents lbladd4 As Label
    Friend WithEvents lbladd3 As Label
    Friend WithEvents txtadd2 As TextBox
    Friend WithEvents txtadd1 As TextBox
    Friend WithEvents lbladd2 As Label
    Friend WithEvents lbladd1 As Label
    Friend WithEvents cmbADD As ComboBox
    Friend WithEvents cmbID As ComboBox
    Friend WithEvents btnadd As Button
    Friend WithEvents txtadvsearch As TextBox
    Friend WithEvents btnadvsearch As Button
    Friend WithEvents cmboperator As ComboBox
    Friend WithEvents btnconfirm As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents cmbtables As ComboBox
    Friend WithEvents dtprep As DateTimePicker
    Friend WithEvents btncancel As Button
    Friend WithEvents lblrep As Label
    Friend WithEvents txtinputbox As TextBox
    Friend WithEvents lblfield As Label
    Friend WithEvents cmbfield As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lblid As Label
    Friend WithEvents btnsearch As Button
    Friend WithEvents btndelete As Button
    Friend WithEvents btnedit As Button
    Friend WithEvents DATAGRID As DataGridView
    Friend WithEvents btnExitadmin As Button
End Class
