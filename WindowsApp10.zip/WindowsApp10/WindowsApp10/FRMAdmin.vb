﻿Imports System.Data.OleDb

Public Class FRMAdmin
    Dim conn As New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Acer\Documents\VBNetCaseStudy.mdb; persist security info = false")
    Dim dt As New DataTable
    Dim strtable As String
    Dim booldel, booledit, boolsearch, booladv, booladd As Boolean


    Public Sub LoadDataGrid()
        strtable = cmbtables.Text
        DATAGRID.DataSource = Nothing
        dt.Rows.Clear()
        dt.Columns.Clear()

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        If strtable = "Order_Details" Then
            loadcombox()
            conn.Open()
            Dim da As New OleDb.OleDbDataAdapter("Select * from Order_Details", conn)
            da.Fill(dt)
            DATAGRID.DataSource = dt
            conn.Close()
        ElseIf strtable = "Orders" Then
            loadcombox()
            conn.Open()
            Dim da As New OleDb.OleDbDataAdapter("Select * from Orders", conn)
            da.Fill(dt)
            DATAGRID.DataSource = dt
            conn.Close()
        ElseIf strtable = "Payment_Methods" Then
            loadcombox()
            conn.Open()
            Dim da As New OleDb.OleDbDataAdapter("Select * from Payment_Methods", conn)
            da.Fill(dt)
            DATAGRID.DataSource = dt
            conn.Close()
        ElseIf strtable = "Product_Details" Then
            loadcombox()
            conn.Open()
            Dim da As New OleDb.OleDbDataAdapter("Select * from Product_Details", conn)
            da.Fill(dt)
            DATAGRID.DataSource = dt
            conn.Close()
        ElseIf strtable = "Users" Then
            loadcombox()
            conn.Open()
            Dim da As New OleDb.OleDbDataAdapter("Select * from Users", conn)
            da.Fill(dt)
            DATAGRID.DataSource = dt
            conn.Close()
        End If

    End Sub


    Private Sub cmbtables_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbtables.SelectedIndexChanged
        LoadDataGrid()
        LoadCmbID()
    End Sub


    Private Sub btnconfirm_Click(sender As Object, e As EventArgs) Handles btnconfirm.Click
        Dim field, ans, ope As String
        field = cmbfield.SelectedItem
        strtable = cmbtables.SelectedItem
        ope = cmboperator.SelectedItem
        Dim emptyBoxes =
        From txt In Me.Controls.OfType(Of TextBox)()
        From cmb In Me.Controls.OfType(Of ComboBox)()
        Where (String.IsNullOrWhiteSpace(txt.Text) And txt.Enabled = True)
        Where (String.IsNullOrWhiteSpace(cmb.Text) And cmb.Enabled = True)


        If booledit = True Then

            If emptyBoxes.Any Then
                MessageBox.Show("Don't leave anything Blank")

            ElseIf field = "Purchase_Date" Then
                Try

                    Dim cmd As New OleDb.OleDbCommand("UPDATE " & strtable & " SET " & field & " = '" & dtprep.Value.ToString("yyyy-MM-dd") & "' WHERE order_id = " & cmbID.Text, conn)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Recorded")
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                Finally
                    conn.Close()
                End Try
            ElseIf strtable = "Payment_Methods" Then
                Try
                    conn.Open()
                    Dim cmd As New OleDb.OleDbCommand("UPDATE " & strtable & " SET " & field & " = '" & txtinputbox.Text & "' WHERE pay_method = '" & cmbID.Text & "'", conn)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Recorded")
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                Finally
                    conn.Close()
                End Try
            Else
                Dim struniqueID As String

                If strtable = "Orders" Then
                    struniqueID = "Order_ID"
                ElseIf strtable = "Order_Details" Then
                    struniqueID = "Purchase_ID"
                ElseIf strtable = "Users" Then
                    struniqueID = "user_id"
                ElseIf strtable = "Product_Details" Then
                    struniqueID = "Product_ID"
                End If

                conn.Open()
                Try
                    Dim cmd As OleDb.OleDbCommand

                    cmd = New OleDb.OleDbCommand("UPDATE " & strtable & " SET " & field & " = ? WHERE " & struniqueID & " = ?", conn)
                    cmd.Parameters.AddWithValue("@inputValue", txtinputbox.Text)
                    cmd.Parameters.AddWithValue("@uniqueID", cmbID.Text)

                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Recorded!")
                Catch ex As Exception
                    MessageBox.Show(MessageBox.Show(ex.Message))
                Finally
                    conn.Close()
                End Try

            End If
            LoadDataGrid()
        End If


        If booldel = True Then
            If emptyBoxes.Any Then
                MessageBox.Show("Don't leave anything Blank")

            ElseIf strtable = "Orders" Then
                ans = MsgBox("Deleting from Orders table will delete all data with the same Order_id. Confirm?", vbYesNo)
                If ans = vbYes Then
                    Try
                        Dim cmd As New OleDb.OleDbCommand("Delete from orders where order_id = " & cmbID.Text, conn)

                        conn.Open()
                        cmd.ExecuteNonQuery()
                        conn.Close()
                        MessageBox.Show("Deleted")

                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    Finally

                        If conn.State = ConnectionState.Open Then
                            conn.Close()
                        End If
                    End Try
                End If
            ElseIf strtable = "Payment_Methods" OrElse strtable = "Product_Details" Then
                Dim struniqueID As String

                If strtable = "Product_Details" Then
                    struniqueID = "Product_ID"
                ElseIf strtable = "Payment_Methods" Then
                    struniqueID = "pay_method"
                End If
                conn.Open()
                ans = MsgBox("Are you sure you want to delete this record", vbYesNo)
                If ans = vbYes Then
                    Try
                        Dim cmd As New OleDb.OleDbCommand("Delete from " & strtable & " where " & struniqueID & " = '" & cmbID.Text & "'", conn)

                        cmd.ExecuteNonQuery()
                        conn.Close()
                        MessageBox.Show("Deleted")
                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    Finally

                        If conn.State = ConnectionState.Open Then
                            conn.Close()
                        End If
                    End Try
                End If

            Else
                Dim struniqueID As String

                If strtable = "Order_Details" Then
                    struniqueID = "Purchase_ID"
                ElseIf strtable = "Users" Then
                    struniqueID = "user_id"
                End If

                conn.Open()
                ans = MsgBox("Are you sure you want to delete this record", vbYesNo)
                If ans = vbYes Then
                    Try
                        Dim cmd As New OleDb.OleDbCommand("Delete from " & strtable & " where " & struniqueID & " = " & cmbID.Text, conn)

                        cmd.ExecuteNonQuery()
                        conn.Close()
                        MessageBox.Show("Deleted")
                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    Finally

                        If conn.State = ConnectionState.Open Then
                            conn.Close()
                        End If
                    End Try
                End If
            End If
            LoadDataGrid()
        End If


        If boolsearch = True Then

            Try
                DATAGRID.DataSource = Nothing
                dt.Rows.Clear()
                dt.Columns.Clear()
                conn.Open()
                If emptyBoxes.Any Or cmboperator.SelectedItem = Nothing Then
                    MessageBox.Show("Don't leave anything blank or select an operator.")

                ElseIf field = "Price" Or field = "Quantity" Or field = "Order_Total" Then

                    Dim query As String = "Select * from " & strtable & " where " & field & " " & ope & " " & Integer.Parse(txtinputbox.Text)
                    Dim da As New OleDb.OleDbDataAdapter(query, conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                ElseIf field = "Purchase_Date" Then
                    Dim query As String = "SELECT * FROM " & strtable & " WHERE " & field & " " & ope & " #" & dtprep.Value.ToString("yyyy-MM-dd") & "#"
                    Dim da As New OleDb.OleDbDataAdapter(query, conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                Else
                    Dim query As String
                    If ope = "LIKE" Then
                        query = "Select * from " & strtable & " where " & field & " " & ope & " '%" & txtinputbox.Text & "%'"
                    Else
                        query = "Select * from " & strtable & " where " & field & " " & ope & " '" & txtinputbox.Text & "'"
                    End If
                    Dim da As New OleDb.OleDbDataAdapter(query, conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                End If
                conn.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            Finally

                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        End If


        If booladv = True Then
            DATAGRID.DataSource = Nothing
            dt.Rows.Clear()
            dt.Columns.Clear()
            conn.Open()
            If emptyBoxes.Any Then
                MessageBox.Show("Don't leave anything Blank")

            Else
                Try
                    Dim da As New OleDb.OleDbDataAdapter(txtadvsearch.Text, conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                Finally

                    If conn.State = ConnectionState.Open Then
                        conn.Close()
                    End If
                End Try
            End If
        End If

        If booladd = True Then
            If emptyBoxes.Any Then
                MessageBox.Show("Don't leave anything Blank")

            ElseIf cmbADD.Text = "Payment_Method" Then
                Try
                    Dim cmd As New OleDb.OleDbCommand("insert into Payment_Methods Values( '" & txtadd1.Text & "','" & txtadd2.Text & "' )", conn)

                    conn.Open()
                    cmd.ExecuteNonQuery()
                    conn.Close()
                    MessageBox.Show("Recorded")

                    conn.Open()
                    Dim da As New OleDb.OleDbDataAdapter("Select * from Payment_Methods", conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                    conn.Close()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                Finally

                    If conn.State = ConnectionState.Open Then
                        conn.Close()
                    End If
                End Try
            ElseIf cmbADD.Text = "Product_Details" Then
                Try
                    Dim cmd As New OleDb.OleDbCommand("insert into product_details Values( '" & txtadd1.Text & "','" & txtadd2.Text & "','" & txtadd3.Text & "'," & Integer.Parse(txtadd4.Text) & " )", conn)

                    conn.Open()
                    cmd.ExecuteNonQuery()
                    conn.Close()
                    MessageBox.Show("Recorded")
                    conn.Open()
                    Dim da As New OleDb.OleDbDataAdapter("Select * from Product_Details", conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                    conn.Close()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                Finally

                    If conn.State = ConnectionState.Open Then
                        conn.Close()
                    End If
                End Try
            ElseIf cmbADD.Text = "Users" Then
                Try
                    Dim cmd As New OleDb.OleDbCommand("insert into Users(User_Name, Pass_Word, Name, user_type) Values( '" & txtadd1.Text & "','" & txtadd2.Text & "','" & txtadd3.Text & "','" & txtadd4.Text & "' )", conn)

                    conn.Open()
                    cmd.ExecuteNonQuery()
                    conn.Close()
                    MessageBox.Show("Recorded")

                    conn.Open()
                    Dim da As New OleDb.OleDbDataAdapter("Select * from Users", conn)
                    da.Fill(dt)
                    DATAGRID.DataSource = dt
                    conn.Close()
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                Finally

                    If conn.State = ConnectionState.Open Then
                        conn.Close()
                    End If
                End Try
            End If
        End If

        cmboperator.Text = ""
        cmbfield.Text = ""
        cmbID.Text = ""
        txtadvsearch.Clear()
        txtinputbox.Clear()
        txtadd1.Clear()
        txtadd2.Clear()
        txtadd3.Clear()
        txtadd4.Clear()
    End Sub

    Private Sub btnExitadmin_Click(sender As Object, e As EventArgs) Handles btnExitadmin.Click
        Me.Close()
        FRMLogin.ShowDialog()
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        cleardatagrid()
        cmbtables.Text = ""
        booldel = True
        booladd = False
        boolsearch = False
        booladv = False
        booledit = False
        btnedit.Enabled = False
        btnsearch.Enabled = False
        lblid.Visible = True
        cmbID.Enabled = True
        cmbID.Visible = True
        btnconfirm.Enabled = True
        btncancel.Enabled = True
        btnconfirm.Visible = True
        btncancel.Visible = True
        btnadd.Enabled = False
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        clearall()
        boolsearch = True
        booldel = False
        booledit = False
        booladd = False
        btndelete.Enabled = False
        btnedit.Enabled = False
        cmboperator.Enabled = True
        cmboperator.Visible = True
        lblfield.Visible = True
        btncancel.Enabled = True
        btncancel.Visible = True
        btnconfirm.Enabled = True
        btnconfirm.Visible = True
        cmbfield.Enabled = True
        cmbfield.Visible = True
        txtinputbox.Visible = True
        txtinputbox.Enabled = True
        btnadvsearch.Enabled = True
        btnadvsearch.Visible = True
        btnadd.Enabled = False
        If booladv = True Then
            txtadvsearch.Enabled = False
            txtadvsearch.Visible = False
        End If

    End Sub

    Private Sub btnadvsearch_Click(sender As Object, e As EventArgs) Handles btnadvsearch.Click
        booladv = True
        booldel = False
        booledit = False
        booladd = False
        cmbfield.Enabled = False
        cmbfield.Visible = False
        txtinputbox.Visible = False
        txtinputbox.Enabled = False
        cmboperator.Enabled = False
        cmboperator.Visible = False
        lblfield.Visible = False
        txtadvsearch.Enabled = True
        txtadvsearch.Visible = True
        boolsearch = False
    End Sub

    Private Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        clearall()
        cmbtables.Items.Clear()
        With cmbtables
            .Items.Add("Order_Details")
            .Items.Add("Orders")
            .Items.Add("Payment_Methods")
            .Items.Add("Product_Details")
            .Items.Add("Users")
        End With
    End Sub

    Sub clearall()
        cleardatagrid()
        cmbADD.Text = ""
        cmbfield.Text = ""
        cmbfield.Items.Clear()
        cmboperator.Text = ""
        cmbID.Text = ""
        cmbID.Items.Clear()
        txtinputbox.Clear()
        txtadvsearch.Clear()
        txtadd1.Clear()
        txtadd2.Clear()
        txtadd3.Clear()
        txtadd4.Clear()
        cmbtables.Enabled = True
        dtprep.Enabled = False
        dtprep.Visible = False
        txtinputbox.Enabled = False
        txtinputbox.Visible = False
        cmbfield.Enabled = False
        cmbfield.Visible = False
        cmbID.Enabled = False
        cmbID.Visible = False
        lblid.Visible = False
        lblfield.Visible = False
        lblrep.Visible = False
        btncancel.Enabled = False
        btncancel.Visible = False
        btnconfirm.Enabled = False
        btnconfirm.Visible = False
        cmboperator.Enabled = False
        cmboperator.Visible = False
        btnadvsearch.Enabled = False
        btnadvsearch.Visible = False
        txtadvsearch.Enabled = False
        txtadvsearch.Visible = False
        btndelete.Enabled = True
        btnsearch.Enabled = True
        btnedit.Enabled = True
        btnadd.Enabled = True
        cmbADD.Enabled = False
        cmbADD.Visible = False
        lbladd1.Enabled = False
        lbladd1.Visible = False
        lbladd2.Enabled = False
        lbladd2.Visible = False
        lbladd3.Enabled = False
        lbladd3.Visible = False
        lbladd4.Enabled = False
        lbladd4.Visible = False
        txtadd1.Enabled = False
        txtadd1.Visible = False
        txtadd2.Enabled = False
        txtadd2.Visible = False
        txtadd3.Enabled = False
        txtadd3.Visible = False
        txtadd4.Enabled = False
        txtadd4.Visible = False

    End Sub
    Private Sub btnedit_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        clearall()
        cmbtables.Items.Remove("Order_Details")
        cmbtables.Items.Remove("Orders")
        booledit = True
        booldel = False
        boolsearch = False
        booladv = False
        booladd = False
        txtinputbox.Enabled = True
        txtinputbox.Visible = True
        cmbfield.Enabled = True
        cmbfield.Visible = True
        cmbID.Enabled = True
        cmbID.Visible = True
        lblid.Visible = True
        lblfield.Visible = True
        btncancel.Enabled = True
        btncancel.Visible = True
        lblrep.Visible = True
        btnconfirm.Enabled = True
        btnconfirm.Visible = True
        btndelete.Enabled = False
        btnsearch.Enabled = False
        btnadd.Enabled = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        clearall()
        cleardatagrid()
        booladd = True
        booladv = False
        booldel = False
        booledit = False
        boolsearch = False
        btnedit.Enabled = False
        btnsearch.Enabled = False
        btndelete.Enabled = False
        cmbtables.Enabled = False
        btnconfirm.Enabled = True
        btnconfirm.Visible = True
        btncancel.Visible = True
        btncancel.Enabled = True
        cmbADD.Enabled = True
        cmbADD.Visible = True

    End Sub

    Private Sub cmbADD_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbADD.SelectedIndexChanged

        If cmbADD.Text = "Payment_Method" Then
            lbladd1.Text = "Pay Method"
            lbladd2.Text = "Available"
            lbladd1.Visible = True
            lbladd1.Enabled = True
            lbladd2.Visible = True
            lbladd2.Enabled = True
            txtadd1.Enabled = True
            txtadd1.Visible = True
            txtadd2.Enabled = True
            txtadd2.Visible = True
        ElseIf cmbADD.Text = "Product_Details" Then
            lbladd1.Text = "Product ID"
            lbladd2.Text = "Name"
            lbladd3.Text = "Description"
            lbladd4.Text = "Price"
            lbladd1.Visible = True
            lbladd1.Enabled = True
            lbladd2.Visible = True
            lbladd2.Enabled = True
            lbladd3.Visible = True
            lbladd3.Enabled = True
            lbladd4.Enabled = True
            lbladd4.Visible = True
            txtadd1.Enabled = True
            txtadd1.Visible = True
            txtadd2.Enabled = True
            txtadd2.Visible = True
            txtadd3.Enabled = True
            txtadd3.Visible = True
            txtadd4.Enabled = True
            txtadd4.Visible = True
        ElseIf cmbADD.Text = "Users" Then
            lbladd1.Text = "Username"
            lbladd2.Text = "Password"
            lbladd3.Text = "Name"
            lbladd4.Text = "User Type"
            lbladd1.Visible = True
            lbladd1.Enabled = True
            lbladd2.Visible = True
            lbladd2.Enabled = True
            lbladd3.Visible = True
            lbladd3.Enabled = True
            lbladd4.Enabled = True
            lbladd4.Visible = True
            txtadd1.Enabled = True
            txtadd1.Visible = True
            txtadd2.Enabled = True
            txtadd2.Visible = True
            txtadd3.Enabled = True
            txtadd3.Visible = True
            txtadd4.Enabled = True
            txtadd4.Visible = True
        End If
        txtadd1.Clear()
        txtadd2.Clear()
        txtadd3.Clear()
        txtadd4.Clear()
    End Sub


    Sub loadcombox()
        cmbfield.Text = Nothing
        cmbfield.Items.Clear()
        strtable = cmbtables.SelectedItem
        If strtable = "Order_Details" Then
            With cmbfield
                .Items.Add("Product_ID")
                .Items.Add("Quantity")
                .Items.Add("Payment_Type")
                .Items.Add("Card_CVV")
            End With

        ElseIf strtable = "Orders" Then
            With cmbfield
                .Items.Add("Purchase_Date")
                .Items.Add("Order_Total")
            End With
        ElseIf strtable = "Payment_Methods" Then
            If booledit = True Then
                cmbfield.Items.Add("Available")
            Else
                cmbfield.Items.Add("pay_method")
                cmbfield.Items.Add("Available")
            End If
        ElseIf strtable = "Product_Details" Then
            With cmbfield
                .Items.Add("Product_Name")
                .Items.Add("Product_Description")
                .Items.Add("Price")
            End With
        ElseIf strtable = "Users" Then
            With cmbfield
                .Items.Add("User_Name")
                .Items.Add("Pass_Word")
                .Items.Add("Name")
                .Items.Add("user_type")
            End With
        End If
    End Sub

    Private Sub LoadCmbID()

        If strtable = "Payment_Methods" Then
            Try
                conn.Open()
                Dim sql As String = "select pay_method FROM " & strtable
                Dim sqlcom As New OleDbCommand(sql, conn)
                Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

                cmbID.Items.Clear()

                While sqlread.Read()
                    cmbID.Items.Add(sqlread("pay_method"))
                End While

                sqlread.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally

                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        ElseIf strtable = "Order_Details" Then
            Try
                conn.Open()
                Dim sql As String = "select Purchase_ID FROM " & strtable
                Dim sqlcom As New OleDbCommand(sql, conn)
                Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

                cmbID.Items.Clear()

                While sqlread.Read()
                    cmbID.Items.Add(sqlread("Purchase_ID").ToString())
                End While

                sqlread.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally

                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        ElseIf strtable = "Orders" Then
            Try
                conn.Open()
                Dim sql As String = "select Order_ID FROM " & strtable
                Dim sqlcom As New OleDbCommand(sql, conn)
                Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

                cmbID.Items.Clear()

                While sqlread.Read()
                    cmbID.Items.Add(sqlread("Order_ID").ToString())
                End While

                sqlread.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally

                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        ElseIf strtable = "Users" Then
            Try
                conn.Open()
                Dim sql As String = "select user_id FROM " & strtable
                Dim sqlcom As New OleDbCommand(sql, conn)
                Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

                cmbID.Items.Clear()

                While sqlread.Read()
                    cmbID.Items.Add(sqlread("user_id").ToString())
                End While

                sqlread.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally

                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        ElseIf strtable = "Product_Details" Then
            Try
                conn.Open()
                Dim sql As String = "select Product_ID FROM " & strtable
                Dim sqlcom As New OleDbCommand(sql, conn)
                Dim sqlread As OleDbDataReader = sqlcom.ExecuteReader()

                cmbID.Items.Clear()

                While sqlread.Read()
                    cmbID.Items.Add(sqlread("Product_ID").ToString())
                End While

                sqlread.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally

                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        End If
    End Sub

    Sub cleardatagrid()
        If DATAGRID.DataSource IsNot Nothing Then
            cmbtables.Text = Nothing
            DATAGRID.DataSource = Nothing
            dt.Rows.Clear()
            dt.Columns.Clear()
        End If
    End Sub

    Private Sub cmbfield_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbfield.SelectedIndexChanged
        If cmbfield.SelectedItem = "Purchase_Date" Then
            txtinputbox.Enabled = False
            txtinputbox.Visible = False
            dtprep.Enabled = True
            dtprep.Visible = True
        Else
            txtinputbox.Enabled = True
            txtinputbox.Visible = True
            dtprep.Enabled = False
            dtprep.Visible = False
        End If

        If boolsearch = True Then
            If cmbfield.SelectedItem = "Price" Or cmbfield.SelectedItem = "Quantity" Or cmbfield.SelectedItem = "Purchase_Date" Or cmbfield.SelectedItem = "Order_Total" Then
                With cmboperator
                    cmboperator.Text = ""
                    cmboperator.Items.Clear()
                    .Items.Add("=")
                    .Items.Add("<")
                    .Items.Add(">")
                    .Items.Add("<>")
                End With
            Else
                With cmboperator
                    cmboperator.Text = ""
                    cmboperator.Items.Clear()
                    .Items.Add("=")
                    .Items.Add("LIKE")
                    .Items.Add("<>")
                End With
            End If
        End If

    End Sub
End Class